# ZeelexPhotography starter

## What is included
- Responsive Next.js website and sample portfolio
- Sign-in/sign-up screen wired to Supabase Auth when credentials are supplied
- Client gallery prototype with unlimited selection toggles (currently sample data only)
- Photographer dashboard UI (sample data only)
- Expo/React Native iOS and Android starter
- Initial Supabase schema for photographer, staff, clients, projects, photos, selections and bookings

This is not yet production-ready: real photo uploads, server-enforced staff assignment, saved selections, role management UI, payment integrations, push/email notifications, tests and app store submission remain to be implemented.

## Step-by-step setup

### 1. Create Supabase
1. Open https://database.new and create an account/project.
2. Choose a project name such as `zeelexphotography`; store the database password somewhere safe.
3. In the project dashboard, open **SQL Editor**, create a new query, paste `supabase/schema.sql`, and run it.
4. In **Project Settings / API** (or **Connect**), copy the Project URL and publishable/anon key.
5. In **Authentication**, set site URL to your local development URL while testing, and configure redirect URLs for local and production domains.
6. In **Storage**, create private buckets named `proofs` and `finals`. Do not upload real client photos until storage authorization policies are implemented and tested.
7. Never expose the service-role key in frontend/mobile apps. Never commit `.env.local`.

### 2. Run the web app locally
Install a current Node.js LTS release.
```bash
cd apps/web
npm install
cp .env.example .env.local
```
Edit `.env.local` with your Supabase URL and publishable/anon key, then run:
```bash
npm run dev
```
Open http://localhost:3000. Try `/login`, `/client-gallery`, and `/dashboard`.
The login form can connect to Supabase Auth once configured. Dashboard and gallery currently display prototype/sample data; they do not yet save selections or manage actual photos.

### 3. Domain and hosting
1. Search for `zeelexphotography.com` first, then alternatives such as `zeelexphotography.co` or `zeelexphotography.ng`. Availability is not guaranteed until checked at a registrar.
2. Register the domain in an account you own. Turn on auto-renewal and two-factor authentication.
3. Deploy the Next.js app to a hosting service (for example, Vercel) and add the domain in its dashboard.
4. Copy the DNS records exactly as provided by the hosting service into the registrar's DNS settings. Do not guess DNS records.
5. Add the production URL to Supabase Auth's allowed redirect URLs.

A domain is separate from hosting and does not automatically publish the website.

### 4. Mobile app
```bash
cd apps/mobile
npm install
npx expo start
```
Use Expo Go for early UI checks. Before store builds, connect the same backend, add sign-in, galleries, uploads/downloads, permission checks and tests, then configure production bundle IDs and store assets.

### 5. Store accounts
- Apple: use https://developer.apple.com/programs/ and enroll with an Apple Account that has two-factor authentication. An individual seller listing shows the legal name; use organization enrollment if the business meets Apple's organization requirements.
- Google: start at https://play.google.com/console/ and follow account verification steps.
- Keep account recovery details and billing under the business owner's control. Fees and requirements can change; confirm them in the official portals before paying.

## Security and production checklist
- Review every RLS policy and test with separate photographer, staff and client accounts.
- Ensure staff can access only projects assigned to them.
- Ensure clients can access only their own projects and photos.
- Use private storage and short-lived signed URLs.
- Implement file type/size limits, rate limits, audit logs, backups and deletion/retention rules.
- Add privacy policy, terms, contact details and account deletion flow.
- Test upload failures, large batches, image download permissions, and unlimited selections.
