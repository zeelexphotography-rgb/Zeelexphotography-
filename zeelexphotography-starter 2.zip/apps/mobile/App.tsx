import React from 'react';
import { SafeAreaView, ScrollView, StatusBar, Text, View, Pressable, StyleSheet } from 'react-native';
const gold = '#E8B52D';
export default function App() {
  return <SafeAreaView style={styles.safe}><StatusBar barStyle="light-content" />
    <ScrollView contentContainerStyle={styles.page}>
      <Text style={styles.brand}>ZEELEX<Text style={{color:gold}}>PHOTOGRAPHY</Text></Text>
      <Text style={styles.eyebrow}>PHOTOGRAPHY · STORYTELLING · MEMORIES</Text>
      <Text style={styles.title}>Capture moments.{"\n"}Tell stories.</Text>
      <Text style={styles.body}>Your photography experience, from booking to final photo delivery.</Text>
      <Pressable style={styles.primary}><Text style={styles.primaryText}>Book a session</Text></Pressable>
      <View style={styles.panel}><Text style={styles.panelTitle}>Your client gallery</Text><Text style={styles.body}>View proof photos, select unlimited favorites, and receive your edited images securely.</Text></View>
      <View style={styles.panel}><Text style={styles.panelTitle}>Your projects</Text><Text style={styles.body}>Bookings · Photo selection · Editing · Final delivery</Text></View>
      <Text style={styles.note}>Starter UI only — authentication, backend, photo uploads and notifications are not connected yet.</Text>
    </ScrollView>
  </SafeAreaView>;
}
const styles = StyleSheet.create({
 safe:{flex:1,backgroundColor:'#101112'},page:{padding:24,paddingTop:40,gap:20},
 brand:{fontSize:18,fontWeight:'900',letterSpacing:2,color:'white'},
 eyebrow:{color:gold,fontSize:11,fontWeight:'700',letterSpacing:1.5,marginTop:30},
 title:{fontSize:42,fontWeight:'800',color:'white',lineHeight:48},
 body:{fontSize:15,lineHeight:23,color:'#c7c7c7'},
 primary:{backgroundColor:gold,padding:16,borderRadius:30,alignItems:'center',marginVertical:8},
 primaryText:{fontWeight:'800',color:'#111'},
 panel:{borderColor:'#393939',borderWidth:1,borderRadius:18,padding:20,gap:10,backgroundColor:'#191a1b'},
 panelTitle:{fontSize:19,fontWeight:'700',color:'white'},
 note:{color:'#858585',fontSize:12,lineHeight:18,marginTop:12}
});
