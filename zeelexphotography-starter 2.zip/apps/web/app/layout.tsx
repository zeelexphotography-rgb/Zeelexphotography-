import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'ZeelexPhotography | Capture Moments. Tell Stories.',
  description: 'Photography portfolio, bookings, private client galleries and final photo delivery.',
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
