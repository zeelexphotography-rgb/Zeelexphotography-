'use client';
import { FormEvent, useState } from 'react';
import { createClient } from '../../lib/supabase/client';

export default function LoginPage() {
  const [mode, setMode] = useState<'signin'|'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage('');
    try {
      const supabase = createClient();
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        setMessage('Account request submitted. Check your email if confirmation is enabled.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        window.location.href = '/dashboard';
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Something went wrong.');
    } finally { setBusy(false); }
  }
  return <main className="shell" style={{maxWidth:520,minHeight:'100vh'}}>
    <nav className="nav"><a className="brand" href="/">ZEELEX<span>PHOTOGRAPHY</span></a></nav>
    <section className="section">
      <div className="eyebrow">Client & team access</div>
      <h1 style={{fontFamily:'Playfair Display,serif',fontSize:42}}>{mode === 'signin' ? 'Welcome back.' : 'Create an account.'}</h1>
      <p className="sub">This sign-in page connects to Supabase after you add your project credentials. Roles must be assigned securely by the photographer, not chosen during public sign-up.</p>
      <form onSubmit={submit} className="card" style={{display:'grid',gap:14}}>
        <label>Email address<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} style={fieldStyle}/></label>
        <label>Password<input required minLength={8} type="password" value={password} onChange={e=>setPassword(e.target.value)} style={fieldStyle}/></label>
        <button className="button" disabled={busy} type="submit">{busy?'Please wait…':mode==='signin'?'Sign in':'Create account'}</button>
        {message && <p role="status" className="sub">{message}</p>}
        <button type="button" onClick={()=>{setMode(mode==='signin'?'signup':'signin');setMessage('')}} style={{border:0,background:'transparent',padding:8,cursor:'pointer'}}>{mode==='signin'?'New client or team member? Create an account':'Already registered? Sign in'}</button>
      </form>
    </section>
  </main>;
}
const fieldStyle: React.CSSProperties = {display:'block',width:'100%',padding:12,marginTop:6,border:'1px solid #e8e5dd',borderRadius:10,font:'inherit'};
