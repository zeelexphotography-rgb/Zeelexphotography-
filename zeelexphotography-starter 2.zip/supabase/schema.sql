-- ZeelexPhotography starter schema. Review policies with a security professional before production.
create extension if not exists pgcrypto;

create type public.app_role as enum ('photographer', 'staff', 'client');
create type public.project_status as enum ('booked', 'proofs_ready', 'selection_submitted', 'editing', 'finals_ready', 'delivered');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role public.app_role not null default 'client',
  created_at timestamptz not null default now()
);

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  client_id uuid not null references public.profiles(id),
  assigned_staff_id uuid references public.profiles(id),
  status public.project_status not null default 'booked',
  session_date date,
  selection_note text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.photos (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  storage_path text not null,
  photo_stage text not null check (photo_stage in ('proof','final')),
  display_number integer,
  caption text,
  uploaded_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.photo_selections (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  photo_id uuid not null references public.photos(id) on delete cascade,
  client_id uuid not null references public.profiles(id),
  selected boolean not null default true,
  updated_at timestamptz not null default now(),
  unique (photo_id, client_id)
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id),
  service_name text not null,
  requested_date date,
  requested_time text,
  notes text,
  status text not null default 'pending' check (status in ('pending','confirmed','completed','cancelled')),
  created_at timestamptz not null default now()
);

create index projects_client_id_idx on public.projects(client_id);
create index projects_staff_id_idx on public.projects(assigned_staff_id);
create index photos_project_id_idx on public.photos(project_id);
create index selections_project_client_idx on public.photo_selections(project_id, client_id);

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.photos enable row level security;
alter table public.photo_selections enable row level security;
alter table public.bookings enable row level security;

create or replace function public.current_role()
returns public.app_role language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.can_access_project(project_uuid uuid)
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.projects p
    where p.id = project_uuid and (
      p.client_id = auth.uid()
      or p.assigned_staff_id = auth.uid()
      or public.current_role() = 'photographer'
    )
  )
$$;

create policy "profiles view self or photographer" on public.profiles for select
using (id = auth.uid() or public.current_role() = 'photographer');
create policy "profiles update self" on public.profiles for update
using (id = auth.uid()) with check (id = auth.uid());

create policy "project access by role" on public.projects for select
using (client_id = auth.uid() or assigned_staff_id = auth.uid() or public.current_role() = 'photographer');
create policy "photographer creates projects" on public.projects for insert
with check (public.current_role() = 'photographer' and created_by = auth.uid());
create policy "photographer updates projects" on public.projects for update
using (public.current_role() = 'photographer') with check (public.current_role() = 'photographer');

create policy "photos visible to project participants" on public.photos for select
using (public.can_access_project(project_id));
create policy "photographer or assigned staff uploads" on public.photos for insert
with check (
  uploaded_by = auth.uid() and (
    public.current_role() = 'photographer'
    or exists(select 1 from public.projects p where p.id = project_id and p.assigned_staff_id = auth.uid())
  )
);

create policy "selection visible to project participants" on public.photo_selections for select
using (public.can_access_project(project_id));
create policy "clients manage own selections" on public.photo_selections for insert
with check (client_id = auth.uid() and exists (
  select 1 from public.projects p where p.id = project_id and p.client_id = auth.uid()
) and exists(select 1 from public.photos ph where ph.id = photo_id and ph.project_id = project_id and ph.photo_stage = 'proof'));
create policy "clients update own selections" on public.photo_selections for update
using (client_id = auth.uid() and exists(select 1 from public.projects p where p.id = project_id and p.client_id = auth.uid()))
with check (client_id = auth.uid());

create policy "bookings visible to owner or photographer" on public.bookings for select
using (client_id = auth.uid() or public.current_role() = 'photographer');
create policy "clients create bookings" on public.bookings for insert
with check (client_id = auth.uid());
create policy "photographer updates bookings" on public.bookings for update
using (public.current_role() = 'photographer') with check (public.current_role() = 'photographer');

-- Create a trigger in a reviewed production migration to create profiles on auth signup.
-- Configure private Storage buckets ('proofs', 'finals') and matching storage.objects policies
-- before uploading any client photographs. Do not make private client galleries public.

-- Automatically create new users as clients. The role cannot be chosen by public sign-up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'client')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Storage setup required before production:
-- 1) Create private buckets named proofs and finals in Supabase Storage.
-- 2) Add storage.objects policies that check bucket_id and can_access_project(project_id)
--    via a safe project_id metadata convention or a server-side signed URL endpoint.
-- 3) Keep bucket contents private and issue short-lived signed URLs only after authorization.
-- 4) Do not put service-role keys in web or mobile environment variables.
